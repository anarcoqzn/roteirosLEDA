package adt.queue;

import adt.heap.GenericHeap;

/**
 * Implementacao de fila usando heap. A ideia é implementar uma fila (com a politica FIFO, respeitando
 * a ordem temporal) usando uma heap como estrutura sobrejacente. Voce deve reutilizar sua implementacao de heap.
 * 
 * Voce nao pode criar nenhum atributo amais na classe!
 *  
 * @author Adalberto
 *
 * @param <T>
 */
public class QueueUsingHeap<T extends Comparable<T>> implements Queue<T> {

	/**
	 * NAO SERA PERMITIDO A CRIACAO DE OUTROS ATRIBUTOS NESTA CLASSE.
	 */
	private int size;
	private GenericHeap<T> heap;
	
	public QueueUsingHeap(int size) {
		//TODO Substitua o codigo abaixo pela instanciacao de sua implementacao de heap (MinHeap ou MaxHeap)
		throw new RuntimeException("Not implemented yet!");
	}
	
	
	@Override
	public void enqueue(T element) throws QueueOverflowException {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public T dequeue() throws QueueUnderflowException {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public T head() {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

}
