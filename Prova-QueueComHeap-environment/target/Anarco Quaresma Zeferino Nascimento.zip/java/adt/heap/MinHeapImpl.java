package adt.heap;

public class MinHeapImpl<T extends Comparable<T>> implements MinHeap<T> {

	private static final int INITIAL_SIZE = 20;
	private static final int INCREASING_FACTOR = 10;
	
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void insert(T element) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Operation not implemented");
	}

	@Override
	public T extractRootElement() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T rootElement() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T[] heapsort(T[] array) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void buildHeap(T[] array) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Operation not implemented");
	}

	private void heapify(int position){
		//TODO
		throw new UnsupportedOperationException("Operation not implemented");
	}
	
	@Override
	public T[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}

}
